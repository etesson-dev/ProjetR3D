let proba = {
    nom: "",
    pourcentage: ""
};
let liste2 = []

function onDrop(event) {
    let target = event.target;

    // récupère les fichiers droppés

    let files = target.files;

    let reader = new FileReader();

    reader.readAsDataURL(files[0]);

    // on recuper l'image
    reader.onload = (e) => {
        let file = {
            name: files[0].name,
            data: e.target.result
        };
        // initilise l'image droppé
        // on recupere la on l'on veut afficher l'image
        let element = document.getElementById("image")
        //on 
        element.src = file.data

        let nomComp = document.getElementById('nomComp')

        proba.nom = file.name.split('.')[0]

        nomComp.innerHTML = proba.nom

        let imageComp = document.getElementById('imageComp')

        imageComp.src = file.data

        let probaComp = document.getElementById('probaComp')

        proba.pourcentage = Math.round(Math.random() * 100) + '%'

        probaComp.innerHTML = proba.pourcentage

        liste2.push(proba)

    }


}

function valider() {
    for (let p of liste2) {
        var newRow = document.createElement('tr');
        console.log("truc"+p.nom)
        newRow.innerHTML = `<td><label> ${p.nom} </label></td><td><label> ${p.pourcentage}</label></td>`
        document.getElementById('valider').appendChild(newRow);
    }

}

function refuser() {
    
        var newRow = document.createElement('tr');
        newRow.innerHTML = '<td><div id="nomComp"></div></td><td><img id="imageComp"/></td><td><div id="probaComp"></div></td>';
        document.getElementById('confirmer')
    

}

function sauvegarder() {
    let text = JSON.stringify(liste2)
    const filename = "sauvegarde.json"

    let element = document.createElement('a');

    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);

    element.style.display = 'none';
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
  }